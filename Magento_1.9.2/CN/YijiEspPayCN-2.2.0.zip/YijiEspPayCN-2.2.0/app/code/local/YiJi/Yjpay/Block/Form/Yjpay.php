<?php
class YiJi_Yjpay_Block_Form_Yjpay extends Mage_Payment_Block_Form
{
/*
     protected function _construct()
    {
        parent::_construct();
        $this->setTemplate('yjpay/pay.phtml');
    } 
*/
}
