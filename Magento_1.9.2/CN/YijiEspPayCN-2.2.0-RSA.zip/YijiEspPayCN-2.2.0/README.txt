# 安装

  1. 登录系统后台

  2. 找到 System > Magento Connect >  Magento Connect Manager

  3. 输入账号密码进入找到 Direct package file upload 项，有个选择文件把下载来下tgz包上传

  4. 上传后会自动安装

  5. 到 System > Configuration > SALES > Payment Methods > YIJIFU Payment for WEB进行启动并填写相关参数配置即可使用

  6. 将snet_20160825020000752433.pfx文件与yiji.snet.cer文件放在网站根目录下，测试环境用测试文件加密，正式环境用收到的正式秘钥公钥文件

  7. 测试环境 File Password 123456


