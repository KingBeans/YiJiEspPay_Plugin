# 测试参数

`到后台填写好地址`

测试请求地址：https://openapi.yijifu.net/gateway.html

正式环境：https://api.yiji.com/gateway.html

ID     20160825020000752433

FILE PASSWORD    123456



