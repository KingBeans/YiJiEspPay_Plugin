<?php
$_['text_title']  = 'Pay by credit card';
