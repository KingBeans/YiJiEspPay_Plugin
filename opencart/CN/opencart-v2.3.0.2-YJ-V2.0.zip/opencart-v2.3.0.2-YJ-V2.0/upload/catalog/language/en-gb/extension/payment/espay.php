<?php

$_['text_title']         = 'YJF-Crossborder Payment Platform';
$_['text_summary']       = 'Yijifu Techology CO,LTD is a company that offers international credit card payment service , certifatied by QSP(Visa) .';
$_['text_order_summary'] = 'YJF-Crossborder Payment Platform submit order';


$_['entry_card_no']     = 'Card Number';
$_['entry_expire_date'] = 'Expire date';
$_['entry_cvv']         = 'Security code';
$_['entry_pay_now']     = 'Use YJF for Payment';

$_['error_card_no_empty']       = 'Credit card number cannot be empty';
$_['error_card_no_invalid']     = 'Credit card number is invalid';
$_['error_expire_date_empty']   = 'Expire date be empty';
$_['error_expire_date_invalid'] = 'Expire date invalid';
$_['error_card_cvv_empty']      = 'Code can not be empty';
$_['error_card_cvv_invalid']    = 'Security code(CVV) format is not correct';




