<?php
    /**
     * yjfpayc-handler.php process yjfpay information
     */

    # import application top
    require('includes/application_top.php');
    require(DIR_WS_MODULES . '/payment/yjfpayc/asynchronous_notification.php');
    
    echo 'success';
